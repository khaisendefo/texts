import{t as o,a,b as r}from"./accordion-footer-DvwObA3J.js";o();a();r();
